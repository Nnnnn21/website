 <footer id="footer" class="footer" style="width: 100%;">
   <div class="copyright">
     Copyright &copy; <script>
     document.write(new Date().getFullYear())
     </script><strong><span> Mentari Sehat Indonesia</span></strong> | All Rights Reserved
   </div>
 </footer>